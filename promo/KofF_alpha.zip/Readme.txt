Knight of Faith v.alpha - README
--------------------------------


!!!!!!!!!!!!!ALPHA TESTAAJAT, LUKEKAA alpha_ohje.txt!!!!!!!!!!!!!!!!!

(t�m� on viel� kesken)

Contents

1. Setup & Start-up
2. Gameplay & Controls
3. Credits
4. Version History

















3. Credits
----------

Project Supervisor	-	Tapio Vierros
Lead Programmer		-	Tapio Vierros
Lead Graphics Artist	-	Tapio Vierros

Special Thanks To "ristis" - my beloved enemy, competitor and idea stealer


4. Public Versions
------------------
(latest first)

City alpha test
 - City/Castle generator
 - NPC-parser
 - Aimed to test the parser in shopping etc situations

Technology demo #1 - Dungeon Generator type 1
 - Demonstarates one of the dungeon generator algorithms
 - Demonstarates Field of View system
 - Inventory
 - Fighting

